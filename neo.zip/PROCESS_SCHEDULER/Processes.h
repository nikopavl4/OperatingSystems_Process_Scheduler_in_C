//Structure Process Declaration
typedef struct Process {
   int   pid;
   int   arrival_time;
   int   process_time;
   int   priority;
}Process;
    

